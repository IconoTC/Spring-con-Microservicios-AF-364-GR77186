package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import es.indra.models.Carrito;
import es.indra.models.Producto;

@Service
public class GestionBSImpl  implements IGestionBS{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public List<Producto> obtenerTodos() {
		String url = "http://localhost:8091/api/productos/listar";
		return null;
	}

	@Override
	public Producto buscar(Long id) {
		String url = "http://localhost:8091/api/productos/buscar/{id}";
		return null;
	}

	@Override
	public Carrito consultar(String nombre) {
		String url = "http://localhost:8091/api/carrito/consultar/{usuario}";
		return null;
	}

	@Override
	public Carrito crear(String usuario) {
		String url = "http://localhost:8091/api/carrito/crear/{usuario}";
		return null;
	}

	@Override
	public void agregar(Long id, int cantidad, String usuario) {
		String url = "http://localhost:8091/api/carrito/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}";
		
	}

	@Override
	public void eliminar(Long id, String usuario) {
		String url = "http://localhost:8091/api/carrito/eliminar/id/{id}/usuario/{usuario}";
		
	}

}
