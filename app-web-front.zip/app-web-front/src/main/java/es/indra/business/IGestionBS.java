package es.indra.business;

import java.util.List;

import es.indra.models.Carrito;
import es.indra.models.Producto;

public interface IGestionBS {
	
	List<Producto> obtenerTodos();
	
	Producto buscar(Long id);
	
	Carrito consultar(String usuario);
	
	Carrito crear(String usuario);
	
	void agregar(Long id, int cantidad, String usuario);
	
	void eliminar(Long id, String usuario);

}
