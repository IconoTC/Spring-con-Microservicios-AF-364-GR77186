package es.indra.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

import es.indra.models.Producto;

@RepositoryRestResource(collectionResourceRel = "PRODUCTOS", path = "productos")
public interface ProductosDAO extends JpaRepository<Producto, Long>{
	
	// Consultar todos los productos
	// http://localhost:8001/productos
	
	// Buscar un producto por id
	// http://localhost:8001/productos/2
	
	// Podemos crear nuestros metodos personalizados utilizando palabras clave
	// https://docs.spring.io/spring-data/jpa/reference/repositories/query-keywords-reference.html
	
	// Todos los metodos personalizados los podeis ver en este enlace
	// http://localhost:8001/productos/search
	
	// http://localhost:8001/productos/search/findByDescripcion?descripcion=Raton
	public List<Producto> findByDescripcion(String descripcion);
	
	// http://localhost:8001/productos/search/OrderByPrecio
	public List<Producto> OrderByPrecio();
	
	// http://localhost:8001/productos/search/OrderByPrecioDesc
	public List<Producto> OrderByPrecioDesc();

	// http://localhost:8001/productos/search/findByPrecioBetween?min=80&max=200
	public List<Producto> findByPrecioBetween(double min, double max);

}
