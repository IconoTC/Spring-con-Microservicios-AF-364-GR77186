package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServicioPuertaEnlaceGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioPuertaEnlaceGatewayApplication.class, args);
	}

}
