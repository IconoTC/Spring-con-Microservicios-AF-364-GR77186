package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

import es.indra.persistence.CarritosDAO;

@SpringBootApplication
@EnableEurekaClient
@EnableFeignClients
public class MicroServicioCarritoEurekaApplication implements CommandLineRunner{
	
	@Autowired
	private CarritosDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioCarritoEurekaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Este metodo se ejecuta cuando ya se ha levando la app y el contexto de Spring se ha creado
		
		// Eliminar todos los datos
		//dao.deleteAll();	
	}

}
