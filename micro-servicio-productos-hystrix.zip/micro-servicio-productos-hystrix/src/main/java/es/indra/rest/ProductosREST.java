package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.models.Producto;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

@RestController
public class ProductosREST {
	
	// Con puerto dinamico no funciona
	//@Value("${server.port}")   // inyecta un valor
	//private Integer port;
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired  // inyecta un bean (objeto)
	private IProductosBS bs;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		// 1ª opcion
//		List<Producto> lista = bs.consultarTodos();
//		for (Producto producto : lista) {
//			producto.setPort(port);
//		}
//		return lista;
		
		// 2ª opcion -> A partir de java 8 utilizaremos los streams
		return bs.consultarTodos()
				.stream()
				.map(prod -> {
					//prod.setPort(port);
					prod.setPort(request.getLocalPort());
					return prod;
				})
				.collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/2
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable(name = "id") Long id) throws InterruptedException {
		Producto producto = bs.buscarProducto(id);
		
		// Si no encontramos el producto, lanzaremos una excepcion
		if (producto.getDescripcion() == null) {
			throw new RuntimeException("Error al buscar el producto");
		}
		
		// Por defecto, los microservicios esperan un maximo de 1 segundo en obtener la respuesta
		// Si la peticion supera ese segundo devuelve un error de Timeout
		// Provoco ese error parando el hilo 5 segundos
		// Podemos ampliar ese tiempo de espera en el application.properties del micro-servicio-pedidos
		Thread.sleep(5000);
		
		//producto.setPort(port);
		producto.setPort(request.getLocalPort());
		return producto;
	}

}



